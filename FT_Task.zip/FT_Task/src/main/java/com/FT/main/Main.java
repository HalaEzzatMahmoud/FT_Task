package main.java.com.FT.main;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;
import org.apache.logging.log4j.core.config.ConfigurationSource;
import org.apache.logging.log4j.core.config.xml.XmlConfiguration;
import org.sikuli.script.FindFailed;

import lombok.extern.log4j.Log4j2;
import main.java.com.FTTask.ManagerCase.RunCase;

@Log4j2
public class Main {

	/**** Main 
	 * @throws FindFailed ****/
	public static void main(String[] args) throws IOException, FindFailed {
		init();
		
		run();
	}

	
	private static void run() throws FindFailed {
		
		log.info("Date 25-09-2024  08:15 pm ") ;
		RunCase.Run();
	}

	private static void init() throws IOException {
		
		initLog();
		
	
	
	}

	/*
	 * This function opens the required tools
	 */
	private static void openTools() {
		// Open required tools
	}

	private static void initLog() throws IOException {
		ConfigurationSource source = new ConfigurationSource(
				new FileInputStream(System.getProperty("user.dir") + "\\config\\log4j2.xml"));
		XmlConfiguration xmlConfig = new XmlConfiguration(null, source);
		Logger logger = (Logger) LogManager.getLogger();
		logger.getContext().start(xmlConfig);
	}

}

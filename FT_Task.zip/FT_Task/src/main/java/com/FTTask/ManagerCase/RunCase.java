package main.java.com. FTTask.ManagerCase;

import org.sikuli.script.FindFailed;

import main.java.com.FTTask.data.LoadedProperties;
import main.java.com.FTTask.pages.AddUser;
import main.java.com.FTTask.pages.Admin;
import main.java.com.FTTask.pages.DeleteUser;
import main.java.com.FTTask.pages.Login;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class RunCase {

	public static void Run() throws FindFailed {
		log.info("Run Case ...") ;
		Login.LoginOrangeHRM(LoadedProperties.userName, LoadedProperties.userName);
		Admin.OpenAdmin();
		int NumOfRecordsBeforeAdd = Admin.getNumberOfRecords();
		AddUser.AddUser("Oezzat", "Oezzat123");
		int NumOfRecordsAfterAdd = Admin.getNumberOfRecords();
		int addDone = NumOfRecordsAfterAdd - NumOfRecordsBeforeAdd;
		if(addDone>0) {
			System.out.println("New User added Succesfully");
			DeleteUser.selectUserByUsername("Oezzat");
			DeleteUser.deleteSelected();
		}else {
			System.out.println("Add New User added Failed");
		}
		
		
		
	}
}

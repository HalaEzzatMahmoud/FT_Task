package main.java.com.FTTask.util;

import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.Properties;

import lombok.SneakyThrows;
import lombok.experimental.UtilityClass;

@UtilityClass
public class Config {
	private final String CONFIG_FILE_PATH = System.getProperty("user.dir") + "\\config\\app.properties";
	Properties prop;

	@SneakyThrows
	public void load() {
		FileReader reader = new FileReader(CONFIG_FILE_PATH);
		prop = new Properties();
		prop.load(reader);
		reader.close();
	}

	public String get(String key) {
		if (prop == null) {
			load();
		}
		return prop.getProperty(key) != null ? prop.getProperty(key).trim() : null;
	}

	@SneakyThrows
	public void set(String key, String value) {
		if (prop == null) {
			load();
		}
		prop.setProperty(key, value);
		FileOutputStream fileOutputStream = new FileOutputStream(CONFIG_FILE_PATH);
		prop.store(fileOutputStream, null);
		fileOutputStream.close();
	}
}

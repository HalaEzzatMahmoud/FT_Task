package main.java.com.FTTask.pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.sikuli.script.FindFailed;

import main.java.com.FTTask.util.Driver;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class DeleteUser {

	public static void selectUserByUsername(String userName) {
		log.info("select User By Username ...") ;

		List<WebElement> rows = Driver.getInstance()
				.findElements(By.xpath("//div[@class='oxd-table-body']/div[@class='oxd-table-card']"));

		for (WebElement row : rows) {
			WebElement usernameCell = row.findElement(
					By.xpath(".//div[contains(@class, 'oxd-table-cell') and contains(text(), '" + userName + "')]"));

			if (usernameCell != null) {
				WebElement checkbox = row.findElement(By.xpath(".//div[@class='oxd-checkbox-wrapper']/label/span"));

				checkbox.click();
				break;
			}
			
		}
	}
	public static void deleteSelected() {
		log.info("Delete Selected ...") ;

        Driver.getInstance().findElement(By.xpath("//button[@class='oxd-button oxd-button--medium oxd-button--label-danger']")).click();
    }

}

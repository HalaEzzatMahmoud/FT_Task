package main.java.com.FTTask.pages;

import org.openqa.selenium.By;
import org.sikuli.script.FindFailed;

import main.java.com.FTTask.util.Driver;
import lombok.extern.log4j.Log4j2;

@Log4j2
public class Admin {
	public static void OpenAdmin() throws FindFailed {
		log.info("Open Admin ...") ;

		Driver.getInstance()
				.findElement(By.xpath("//a[@href='/web/index.php/admin/viewAdminModule']/span[text()='Admin']"))
				.click();


	}

	public static int getNumberOfRecords() {
		log.info("Get Number of Records  ...") ;

		String recordCountText = Driver.getInstance().findElement(By.xpath("//div[@class='oxd-text oxd-text--span']"))
				.getText();
		String[] spliterRecordCountText = recordCountText.split(" ");
		int recordCount = Integer.parseInt(spliterRecordCountText[0]);
		return recordCount;
	}
	
}

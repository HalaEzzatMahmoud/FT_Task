package main.java.com.FTTask.pages;

import org.openqa.selenium.By;
import org.sikuli.script.FindFailed;

import main.java.com.FTTask.ManagerCase.RunCase;
import main.java.com.FTTask.data.LoadedProperties;
import main.java.com.FTTask.util.Config;
import main.java.com.FTTask.util.Driver;

import lombok.extern.log4j.Log4j2;

@Log4j2
public class Login {

	public static void LoginOrangeHRM(String userName, String password) throws FindFailed {
		log.info("Login ...") ;

		Driver.getInstance().navigate().to(LoadedProperties.OrangeHRMLink);
		if (!Driver.getInstance().findElements(By.id("//button[@type='submit']")).isEmpty()) {
			Driver.getInstance().findElement(By.name("username")).sendKeys(userName);
			Driver.getInstance().findElement(By.xpath("//button[@type='submit']")).sendKeys(password);
			Driver.getInstance().findElement(By.id("nsg-x1-logon-button")).click();
		}
		
	}


}

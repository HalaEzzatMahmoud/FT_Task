package main.java.com.FTTask.data;

import main.java.com.FTTask.util.Config;

import lombok.experimental.UtilityClass;

@UtilityClass
public class LoadedProperties {
	
	public final String userName = Config.get("userName");
	public final String password = Config.get("password");
	public final String OrangeHRMLink = Config.get("OrangeHRMLink");
	
}
